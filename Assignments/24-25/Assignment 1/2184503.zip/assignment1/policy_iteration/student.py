import numpy as np

def reward_function(s, env_size):
    r = 0.0
    r = (s == np.array([env_size-1, env_size-1])).all()
    return r


def transition_probabilities(env, s, a, env_size, directions, holes):
    cells = []
    probs = []
    s_prime = s + directions[a]
    s_second = s + directions[(a-1) % len(directions)]
    
    if not(s_prime[0] < env_size and s_prime[1] < env_size and (s_prime >= 0).all()) or holes[s_prime[0], s_prime[1]]: 
            s_prime = s

    if not(s_second[0] < env_size and s_second[1] < env_size and (s_second >= 0).all()) or holes[s_second[0], s_second[1]]:
            s_second = s

    prob_next_state = np.zeros((env_size, env_size))

    prob_next_state[s_prime[0], s_prime[1]] = 0.5
    prob_next_state[s_second[0], s_second[1]] = 0.5
    

    return prob_next_state
